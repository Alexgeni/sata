<head>


      <script src="https://code.jquery.com/jquery-3.1.1.min.js" ></script>


  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.js" crossorigin="anonymous"></script>


  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.4/angular.min.js"></script>


  <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.4/angular-sanitize.js"></script>
  

  <script src="<?php echo e(asset('/js/inter.js')); ?>"></script>
  

  <meta charset="utf-8">
  

  <title ng-bind="title"></title>
  

  <meta name="description" content="tv channels">
  
    

  <meta name="viewport" content="width=device-width, initial-scale=1">
  

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  

  <script>
  

    (function(i, s, o, g, r, a, m) {
  
      i['GoogleAnalyticsObject'] = r;
  
      i[r] = i[r] || function() {
  
        (i[r].q = i[r].q || []).push(arguments)
  
      }, i[r].l = 1 * new Date();
  
      a = s.createElement(o),
  
        m = s.getElementsByTagName(o)[0];
  
      a.async = 1;
  
      a.src = g;
  
      m.parentNode.insertBefore(a, m)
  
    })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga');




    ga('create', 'UA-92414747-1', 'auto');

    ga('send', 'pageview');

  </script>


  <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
  

  <script src="<?php echo e(asset('/js/ajax.js')); ?>"></script>



</head>