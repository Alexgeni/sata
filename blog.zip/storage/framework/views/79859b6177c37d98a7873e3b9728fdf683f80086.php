<!DOCTYPE html>
<html lang="en" ng-app="trans" ng-controller="en">



<?php echo $__env->make('layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<body lang="<%lang%>" dir="<%dir%>">

  <div class="loading">

    <i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>
      

      <span class="sr-only">Loading...</span>
  
  </div>
  

  <div class="lang"><a>ar</a></div>
  



<?php echo $__env->make("layouts.nav", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>





<?php echo $__env->yieldContent('content'); ?>



<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



</body>

</html>