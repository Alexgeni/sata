<?php $__env->startSection('content'); ?>

  
  <div class="ads"></div>
  
  <div class="search-parent">
  
    <div class="search-div">
  
      <input type="text" autocomplete="off" name="search" id="search" placeholder="<%search%>" onkeyup="showResult(this.value)" />
  
      <div id="livesearch"></div>
  
    </div>
  
  </div>
  
  <div class="ads"></div>




<?php $__env->stopSection(); ?>


<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>