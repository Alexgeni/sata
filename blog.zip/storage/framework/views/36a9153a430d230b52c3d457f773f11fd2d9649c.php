<?php $__env->startSection('content'); ?>

  
 
  <div class="search-parent">
    <div class="search-div">
      <input type="text" autocomplete="off" name="search" id="search" placeholder="<%search%>" onkeyup="showResult(this.value)" />
      <div id="livesearch"></div>
    </div>
  </div>
  <h3 class="ttitle">Frequency of <?php echo e($items->name); ?> Channel <br><small>Last update in <?php echo e($items->updated_at); ?></small>
  </h3>
  

  <div class="table">
    <table>
      <tr>
        <th>Channel name </th>
        <td><?php echo e($items->name); ?></td>
      </tr>
      <tr>
        <th>Satallite</th>
        <td><?php echo e($items->sata); ?></td>
      </tr>
      <tr>
        <th>Frequency</th>
        <td><?php echo e($items->freq); ?></td>
      </tr>
      <tr>
        <th>Polarization</th>
        <td><?php echo e($items->polar); ?></td>
      </tr>
      <tr>
        <th>Sample rate</th>
        <td><?php echo e($items->srate); ?></td>
      </tr>
      <tr>
        <th>FEC</th>
        <td><?php echo e($items->fec); ?></td>
      </tr>
    </table>
    <!-- table -->
  </div>
  <div class="ads"></div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make("layouts.master", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>