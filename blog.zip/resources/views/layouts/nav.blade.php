
  <header>
  
    <h1><%title%></h1>
  
    <nav>
  
      <ul>
  
        <li>
  
          <a href="/"><%home%></a>
  
        </li>



        <li>
  
          <a href="create"><%add%></a>
  
        
        </li>
  
        


        <li>
  
          <a href="about"><%about%></a>
  
        </li>
  
      </ul>
  
    </nav>
  
  </header>
