
  <footer>

    <ul>

      <label><%map%>:</label>

      <li>

        <a><%home%></a>

      </li>

      <li>

        <a><%about%></a>

      </li>

    </ul>

    <p><%dtitle%> <strong><%designer%></strong></p>

    <p><%desc%></p>

    <p>Copyright &copy; 2017</p>

  </footer>

  <script>

    $(document).ready(function() {

      $(".loading").fadeOut(2000);

    });

  </script>


